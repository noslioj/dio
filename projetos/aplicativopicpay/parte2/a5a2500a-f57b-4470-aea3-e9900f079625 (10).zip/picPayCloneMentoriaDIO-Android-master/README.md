# picPayCloneMentoriaDIO-Android
Aplicativo que simula funcionalidades do Pic Pay
