package br.com.dio.picpayclone.ui.login

import androidx.lifecycle.ViewModel

class LoginViewModel() : ViewModel() {

}