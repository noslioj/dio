package br.com.dio.picpayclone.data

data class Login(
    val login: String,
    val senha: String
)