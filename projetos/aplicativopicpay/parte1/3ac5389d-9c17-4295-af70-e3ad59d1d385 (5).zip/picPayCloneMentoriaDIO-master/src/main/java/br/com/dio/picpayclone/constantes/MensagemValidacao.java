package br.com.dio.picpayclone.constantes;

public class MensagemValidacao {

	public static final String ERRO_USUARIO_INEXISTENTE = "O usuário informado não existe na base de dados.";

	
}
