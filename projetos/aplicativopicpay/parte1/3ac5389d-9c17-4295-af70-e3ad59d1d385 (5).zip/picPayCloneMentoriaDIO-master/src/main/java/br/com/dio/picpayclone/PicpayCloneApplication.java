package br.com.dio.picpayclone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PicpayCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(PicpayCloneApplication.class, args);
	}

}
