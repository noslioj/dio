package br.com.dio.picpayclone.service;

import br.com.dio.picpayclone.dto.CartaoCreditoDTO;

public interface ICartaoCreditoService {

	CartaoCreditoDTO salvar(CartaoCreditoDTO cartaoCreditoDTO);
	
}
