package br.com.dio.picpay.picpayclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PicpayCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
