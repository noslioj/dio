package br.com.dio.picpayclone.data

data class Sort(
    val empty: Boolean = true,
    val sorted: Boolean = true,
    val unsorted: Boolean = true
)