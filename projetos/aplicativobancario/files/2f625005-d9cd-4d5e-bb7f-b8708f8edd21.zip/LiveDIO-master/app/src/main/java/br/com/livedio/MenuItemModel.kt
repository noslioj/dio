package br.com.livedio

class MenuItemModel(
    val titulo: String
)